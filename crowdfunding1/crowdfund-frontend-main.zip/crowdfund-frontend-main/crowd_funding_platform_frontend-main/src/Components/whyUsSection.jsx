import React from "react";
import ChildImage from "./assets/whyUsSection-happyKids.jpg";
import styles from "./styles/whyUsSection.module.css";

const WhyUs = () => {
  return (
    <React.Fragment>
      <div className="row col-12">
        <div className={`col-md-8 ${styles.whyUs}`}>
          <h1 className={styles.header}>Why us ?</h1>
          <p className={styles.p}>
        <b>Global Reach:</b>Connect with backers worldwide.<br/>
        <b>Secure Transactions:</b>  Built-in fraud protection for safe crowdfunding.<br/>
        <b>Community-Driven:</b> A platform that values collaboration and social impact.<br/>
          </p>
        </div>
        <div className="col-md-4">
          <img className={styles.image} src={ChildImage} alt="HappyKids" />
        </div>
      </div>
    </React.Fragment>
  );
};

export default WhyUs;
